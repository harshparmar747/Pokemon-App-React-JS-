# README

## Setup

Getting started with this project is very easy. Run:

```
npm install
npm start
```

If you get a `react-scripts start` error, then remove the `node_modules`
folder and re-run the two commands in the code block.

## Demo

#### Piano UI
<div class="flex flex-row">
  <img src="./img/piano_0.png" width="400">
  <img src="./img/piano_2.png" width="400">
</div>
